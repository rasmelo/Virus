
                          VDAT Release 2.000.0
                          ====================

The time has arrived. Contrary to what I stated in my last editorial this
will be the last PUBLIC release of VDAT. After a little more than 4 years
with 10 releases for DOS and 11 for Windows/HTML I have decided to quit
releasing VDAT to the general public.

I will not go into a lot of detail on the "Why?" but I have always stated I
would quit when it would stop being fun. Events and incidents during the last
year have drastically decreased the fun I was having creating this product.
The virus scene is a mess and the small measure of maturity and common decency
that existed in it has all but evaporated. There are of course always
exceptions and I hope these exceptions will continue to be worthwhile.

The recent explosion of the number of virus traders has certainly muddied the
waters of virus collecting. The number of websites offering virus trading has
almost quadrupled in the last couple of months and it seems that this growth
will continue for a while. It has not done the core goal of virus collecting
much good. A lot of junk is being traded and personalities, morals and values
have clashed. It is one of the reasons I have decided to lay low for a while,
I have had enough of the bickering and name calling. When I started collecting
viruses ratios were used just like now, but ultimately when push came to shove
much more was shared than now. People were often inclined to help the new guy
on the block, now it almost seems virus trading is like the stock market: a
matter of plusses and minuses.

I will still update the VDAT product for my own purposes and it will remain
available to most of the insiders of the scene. The update cycle will no
longer be 3 months but it will be determined by the available spare time, it
might be more but also less than 3 months. The only way for the general user
to obtain an unrestricted copy of VDAT is to get me something from my wanted
list (check the VDAT page or this release of VDAT).

As of January 11th 2000 my website supporting VDAT will cease to exist and my
e-mail account will be closed. My new e-mail address will be
cicatrix@worldmail.nl or vdat@crosswinds.net. Distribution of future releases
will be on a case by case basis. The VDAT home page will move and can be found
using the http://vdat.cjb.net URL redirector

SOR (StartOfRant):
==================

I just want to say something about this millennium hype/hoax that is happening
as I release this edition of VDAT. The transition from 1999 to 2000 might be
nice "round number" occasion to have extra celebrations but as far as I am
concerned the next millennium does not start until January 1st 2001. Assuming
there was no year 0 (zero) the year 1 was the first year of the 1st century
and the 1st millennium. Consequently the year 1001 was the 1st year of the 2nd
millennium and the year 2001 will be the 1st year of the 3rd millennium. Also
the correct term for the 2-digit versus 4-digit date annotation problem in
computers should be the Year 2000 bug (or Y2k) and NOT the Millennium bug (or
even worse Millennium virus) as some people call it. So celebrate all you want
but don't call the year 2000 the 21st century or the next millennium, those
won't start for another year. And BTW, January 1st 2000 is just another day of
the week: I'll still get out of bed the same way, I'll still have to walk the
dog and my pay won't change. So what is all the fuss about?

   More material to convince the non believers:

   http://psyche.usno.navy.mil/millennium/whenls.html
   http://members.tripod.com/~PHILKON/millennium.html 

For those wondering about the version number of this release: the similarity
with the year of release and my statement above is just coincidental :-),
future releases will be numbered using the Y.EAR.# format. Consequently the
next release will be 2.000.1 and the first release of next year will be
2.001.0 etc. etc. As you notice I do use 0 (zero).

EOR (EndOfRant)

Cicatrix
January 2000

                             Acknowledgements:
                             =================

For more information about the past, present and future of VDAT please read
my "Editorial" linked on VDAT's main page.

I'd like to thank those that have contributed and still contribute to my
collection and those that have provided information for use in VDAT.

         In alphabetical order:

         - 1nternal
         - Anti-State Tortoise
         - Aurodreph
         - Bayros
         - Billy Belceb�
         - Bozo
         - Chili
         - Cryotek
         - Dark Fiber
         - Dark Killer
         - Dark Knight
         - Darkman
         - Darkside
         - D.G. (Italy)
         - Dirty Nazi
         - Duke (SMF)
         - Evil Avatar
         - Evul
         - Executioner
         - Foxz
         - Glitch
         - God@rky
         - Gothmog
         - Griyo
         - Horny Toad
         - Icebreaker
         - Jack T. Ripper
         - jackie twoflower
         - Jerk1N
         - JHB
         - Knight Of Virus
         - Knowdeth
         - Kronos
         - Landing Camel
         - LovinGod
         - Lord Arz
         - Lord Julius
         - Lord Natas
         - Lucifer Messiah
         - Methyl
         - MGL
         - Mister Sandman
         - Neophyte
         - Nightmare Joker
         - Nucleii
         - Omega
         - Opic
         - Poltergeist
         - Putoksa Kawayan
         - Pyro
         - Owl
         - Q The Misanthrope
         - Recoder
         - RedArc
         - Reptile
         - Rhape79
         - Sepultura
         - Shadow Seeker
         - Silver Surfer AKA ...
         - Slagehammer
         - Spanska
         - Spooky
         - Stealth Warrior
         - Stormbringer
         - Tally
         - Talon
         - Techno Phunk
         - The Unforgiven
         - Ultras
         - Vecna
         - VEiN
         - VicodinES
         - Virogen
         - Virtual Daemon
         - VirusBuster
         - WaveFunc
         - Zhuge Jin

         and quite a few I'm sure don't want to be mentioned by name or
         handle ;-) (you know who you are!) or some that I forgot (my
         apologies).
