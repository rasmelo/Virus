//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by pib.rc
//
#define IDD_DIALOG1                     101
#define IDD_MAIN                        101
#define IDD_PLUGIN                      106
#define IDR_MENUPLUG                    107
#define IDD_OPT                         108
#define IDD_WORK                        109
#define IDI_ICON1                       110
#define IDI_MYICON                      201
#define IDC_LIST1                       1000
#define IDC_APPLY                       1000
#define IDC_PICKFILE                    1003
#define IDC_OFILE                       1005
#define IDC_OPTBUT                      1009
#define IDC_BUTTON3                     1010
#define IDC_BUTTON4                     1011
#define IDC_GO                          1012
#define IDC_LISTPLUG                    1013
#define IDC_CHECK1                      1014
#define IDC_CHECK2                      1015
#define IDC_CHECK3                      1016
#define IDC_WORK1                       1018
#define IDC_STATIC2                     1019
#define IDC_STATIC3                     1020
#define ID_FILE_PROPERTIES              40001
#define ID_FILE_EXIT                    40002
#define ID_FILE_BLAH                    40003
#define ID_FILE_OPTIONS                 40004
#define ID_FILE_PLUGINS                 40005
#define ID_FILE_ABOUT                   40006
#define ID_FILE_ADD                     40007
#define ID_FILE_REMOVE                  40008
#define ID_FILE_PROPERTIES40009         40009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40010
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
