//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by spyrc.rc
//
#define INT2ESPY_DIALOG                 101
#define IDI_ICON1                       102
#define IDSPYNOW                        1000
#define IDC_FILE_TO_SPY                 1001
#define IDC_STATIC1                     1002
#define IDC_FILE_FOR_LOG                1003
#define IDTRANSLATE                     1004
#define IDUNLOAD                        1005
#define IDC_STATIC2                     -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
