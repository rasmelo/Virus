#define	CATCHY_ERROR	0xffffffff

#ifdef __cplusplus
extern "C" {
#endif
	DWORD __cdecl c_Catchy(PVOID);
#ifdef __cplusplus
}
#endif

#pragma comment(lib, "catchy32")

