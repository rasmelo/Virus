#define STUB_API_PTR 1
#define STUB_API2_PTR 6

#define ENTRY_EPOINT 1
#define ENTRY_GETMHND 7
#define ENTRY_GETPROCA 0xc
#define ENTRY_EXE_SIZE 0xa8

#define ENTRY_PTR 0x1238



