#include <stdio.h>

main(void)
{
	printf("test\n");
	return 0;
}
